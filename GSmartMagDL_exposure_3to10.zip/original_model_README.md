# Randomized physical target exposure (dipole approximation)

Created 2026-10-19. This extends the previous fixed 2 m disk scenario.
It randomizes physical source parameters, not arbitrary field amplitudes.
Outputs are model-based exposure probabilities, NOT detector performance.

## Parameters and provenance

Public repository: https://github.com/eladfishergit/GSmartMagDL
Source parameter ranges: build_ground_truth1.m,
blob 99ea3456ba8303241ef032ac14a2e0b487adcc14.
Trajectory law: CreateTrajectories_all.m,
blob 22b7a2a6262c4bfbf0d9ebf13a2c1f5d640ea9cb.
Measurement/noise setup: build_full_database_MV_HRDTraj_new_algo.m,
blob cf48fd7357a23467b1c274f70d472589ec9152ad.

Each target independently receives D~U(0.025,0.030) m, L~U(0.8,1.2) m,
f~U(1,2), M=1.2706/(mu0*f) A/m, m=M*pi*D^2*L/4 A m^2.
Its orientation is uniformly selected from +x,-x,+y,-y. Its center is
uniform in [-10,10]^2, following the inspected placement rule within the
30 x 30 m map. Height separation h=1 m. Background field (3,29,33) µT.
Source parameters, orientations and positions are independent.

IMPORTANT implementation scope: independently randomized D,L,M per target
is the user's requested model here. The inspected old MATLAB generator
draws vectors but passes D(1),L(1),M(1) to ParallelGenerateReadings, apparently
sharing that first target's parameters across a map. Thus this calculation
matches the stated per-target parameter scenario, NOT that literal old
call. Confirm against the updated generator before claiming exact parity.
Also, the repository field is a finite-cylinder model; this calculation
uses a point dipole for the requested mathematical approximation. It is
not a numerical reproduction of ParallelDerby.

No shape, model, signal, target-count or noise parameters were tuned to
make 20 trajectories look optimal. Seed and scenario settings are explicit.

## Field and exposure definition

mu0=4*pi*1e-7. For target j with moment vector m_j and displacement r:

B_j(r) = (mu0/(4*pi)) [3 r (m_j dot r)/|r|^5 - m_j/|r|^3].

The code computes this in microtesla, then uses the exact magnitude
difference for this approximate source field:

DeltaT_j(x) = ||B_E+B_j(x)|| - ||B_E||.

No linear projection approximation is applied. The informative region is
F_j(tau) = {x : |DeltaT_j(x)| >= tau}. It is generally noncircular and has
direction-dependent weak regions. Fixed-radius assumptions are removed.

For path samples P_i, define
H_j(N,tau) = 1[max_{i<=N,p in P_i}|DeltaT_j(p)| >= tau].

Expected fraction exposed = E[(1/K) sum_j H_j].
Probability all K exposed = E[product_j H_j], estimated as a joint event,
not a product of marginal probabilities. Expected missed = K*(1-q_N).

Primary threshold tau=3 µT = 3 sigma, using nominal sigma=1 µT from the
public per-axis noise model. Sensitivity curves use 2 and 4 µT. Isotropic
small independent axis noise gives approximately sigma scalar noise, but
calibration errors, drift, and real phone processing are not included in
this threshold. No fresh noisy readings are simulated; exposure means a
noiseless modeled anomaly exceeds a chosen amplitude threshold. This is
NOT a 3-sigma detection probability or a detector false-alarm calculation.
Taking a maximum over many correlated samples requires separate detection
calibration if actual detector performance is claimed.

Each source is evaluated against the background in isolation. Overlapping
source fields can reinforce or cancel and are not modeled in this exposure
criterion. Separate resolvability of close targets is not established.
The target-independent response isolates geometric observability under the
reference source family. Actual multi-source reconstruction metrics must
validate performance. No measured-device sensitivity is established here.

## Trajectories and Monte Carlo

Draw P1 uniformly from [-15,15]^2 until ||2P1||>=30 m. P4=-P1.
P2,P3 are independent uniform points in the square. Sample the cubic
Bezier curve at 500 equally spaced t values. Match the MATLAB retained
indices find(diff(x)~=0), excluding the last point. No claim is made that
all real crowdsourced trajectories follow this law.

Generate 3000 independent scenes, each with 10 targets and 50 independent
paths. Each scene's target parameters stay fixed as paths accumulate.
K=3,...,10 uses the first K targets; individual-source exposure means this
does not change target fields. All curves are paired across thresholds
and the 2 m geometric comparison uses the same scenes.

Uncertainty shading: approximate +/-1.96 standard errors of scene-level
all-target indicators. These quantify Monte Carlo uncertainty conditional
on the model, not uncertainty in physical model or actual phone errors.
Scenes, not individual targets within a scene, are independent units.

## Outputs and reproduction

Run `python physical_footprint.py`, requiring numpy and matplotlib.
- physical_exposure.png and .pdf: main graph at 3 µT threshold.
- threshold_comparison.png: 2/3/4 µT and fixed-radius comparison.
- threshold_2uT.csv, threshold_3uT.csv, threshold_4uT.csv: N=0..50,
  target counts 3..10, rates as fractions and MC standard errors.
- summary.json: selected numeric results.
- scene_data.npz: per-scene per-path per-target maximum scalar anomaly,
  geometric circle hits, moments, parameters. Parameter columns:
  target_x_m,target_y_m,D_m,L_m,f,orientation_index (+x,-x,+y,-y).
- physical_footprint.py: self-contained code.

Suggested caption: Model-based exposure probability for randomized
reference targets under a dipole approximation. A target is exposed when
at least one retained trajectory sample has an isolated-target scalar
anomaly magnitude of at least 3 µT relative to the reference background.
Source dimensions, magnetization and orientation are independently
randomized within the stated reference ranges. Results average 3000
independent scenes; shaded bands indicate approximate 95% Monte Carlo
intervals. Exposure denotes a modeled signal opportunity and does not
imply target detection, separation or accurate reconstruction.
