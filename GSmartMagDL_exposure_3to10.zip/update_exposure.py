"""Variable target counts, equal scene weights. Run python update_exposure.py.
Reuses isolated-source field evaluations; independently chooses K per scene.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent
d=np.load(root/'source_scene_data.npz')
peaks=np.maximum.accumulate(d['max_signal_uT'],axis=1)
M,N,Kmax=peaks.shape
seed=2026102001
rng=np.random.default_rng(seed)
K=rng.integers(3,11,size=M)
mask=np.arange(Kmax)[None,:]<K[:,None]
hit=peaks>=3.0
scene_fraction=(hit*mask[:,None,:]).sum(axis=2)/K[:,None]
mean=np.r_[0,scene_fraction.mean(axis=0)]
se=np.r_[0,scene_fraction.std(axis=0,ddof=1)/np.sqrt(M)]
lo=np.maximum(0,mean-1.96*se);hi=np.minimum(1,mean+1.96*se)
assert K.min()==3 and K.max()==10
assert np.all(np.diff(scene_fraction,axis=1)>=0)
assert np.allclose(scene_fraction[0],hit[0,:,:K[0]].mean(axis=1))
n=np.arange(N+1)
np.savetxt(root/'mean_exposure_3to10.csv',np.column_stack([n,mean,se,lo,hi]),delimiter=',',header='trajectories,mean_scene_exposure,mc_se,mc95_lower,mc95_upper',comments='')
np.savez_compressed(root/'variable_count_results.npz',target_counts=K,selected_target_mask=mask,scene_exposure=scene_fraction)
summary={'scenes':M,'count_seed':seed,'count_distribution':'discrete uniform 3 through 10; independent of field/path generation','count_histogram':{str(k):int(np.sum(K==k)) for k in range(3,11)},'total_selected_targets':int(K.sum()),'weighting':'each scene has equal weight','selected':{str(k):{'mean_pct':float(100*mean[k]),'mc95_halfwidth_pp':float(196*se[k])} for k in [10,20,30,50]}}
(root/'summary.json').write_text(json.dumps(summary,indent=2))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':250})
fig,ax=plt.subplots(figsize=(7.8,4.8))
ax.fill_between(n,lo*100,hi*100,color='#206e86',alpha=.22,label='Approximate 95% Monte Carlo interval')
ax.plot(n,mean*100,color='#174c65',lw=2.3,label='Mean exposure (3–10 targets per scene)')
sel=np.array([10,20,30,50]);ax.scatter(sel,mean[sel]*100,color='#174c65',s=35,zorder=4)
for k in sel:ax.annotate((f'{100*mean[k]:.3f}%' if k==50 else f'{100*mean[k]:.2f}%'),(k,mean[k]*100),xytext=(-6 if k==50 else 0,-22),textcoords='offset points',ha='right' if k==50 else 'center',fontsize=10,color='#174c65')
ax.set(xlim=(0,51),ylim=(0,104),xticks=[0,10,20,30,40,50],yticks=[0,20,40,60,80,100],xlabel='Number of trajectories',ylabel='Mean target exposure (%)')
ax.grid(alpha=.18);ax.legend(loc='lower right',frameon=False,fontsize=9)
fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(root/f'mean_target_exposure_3to10.{ext}')
print(json.dumps(summary,indent=2))
