# Corrected exposure average: 3–10 targets per scene

Supersedes the fixed-10-target mean-exposure graph and paragraph.
For each of 3000 independent scenes, K_s is drawn independently uniformly
from integers 3 through 10 using seed 2026102001. Each scene has equal
weight, irrespective of K_s. The selected counts total 19471 targets.

Implementation reuses previously computed independent isolated-target
signals and selects the first K_s targets of each scene. Since target
parameters are iid and independent of the new counts, and sources were
evaluated separately without interactions, this is distributed as a new
variable-count scene sample. Field evaluations were NOT rerun. The unused
targets do not enter any scene mean or any field sum. This would not be
valid for an interacting-source calculation without recomputing the fields.

Run `python update_exposure.py` with numpy and matplotlib installed.
source_scene_data.npz holds original isolated-target computations;
variable_count_results.npz records K_s, selected mask, and scene fractions.
mean_exposure_3to10.csv gives fractions, scene-based MC standard errors,
and clipped approximate normal 95% Monte Carlo intervals. These quantify
Monte Carlo uncertainty only, not physical model uncertainty. At near-unit
rates a normal interval is only a rough summary; no zero-miss guarantee is
implied. summary.json gives histogram and key results.

manuscript.tex contains updated paragraph, formula, and figure caption.
PNG, PDF and SVG plots contain a single exposure curve. The 50-path label
uses three decimals to avoid rounding 99.9967% to apparent exact 100%.

Original physical assumptions, code provenance and model limitations are
retained in original_model_README.md. original_physical_footprint.py is the
original source generator. Fields use a point-dipole approximation and an
exact scalar-magnitude difference against the background, for each target
in isolation. Threshold 3 microtesla; nominal noise 1 microtesla. The source
model is NOT the exact finite-cylinder model or full multi-target readings.
Independent per-target physical parameter randomization matches the requested
scenario, not the older MATLAB call sharing first-target parameters.
