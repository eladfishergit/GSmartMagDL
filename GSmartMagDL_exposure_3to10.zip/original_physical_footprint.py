"""Dipole-based target exposure under randomized source parameters.
This is an approximation to the repository's finite-cylinder field model.
Run python physical_footprint.py (numpy and matplotlib).
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parent
SEED=2026101903
SCENES=3000
N=50
K=10
RNOISE=1.0 # microtesla per axis; nominal scalar approximation
THRESHOLDS=np.array([2.,3.,4.]) # microtesla, fixed noiseless amplitude thresholds
EARTH=np.array([3.,29.,33.]) # microtesla
H=1.0
rng=np.random.default_rng(SEED)
t=np.linspace(0,1,500)[:,None]
basis=np.hstack([(1-t)**3,3*(1-t)**2*t,3*(1-t)*t*t,t**3])
orientations=np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0]])

def paths():
    controls=np.empty((N,4,2))
    for i in range(N):
        while True:
            p1=rng.uniform(-15,15,2)
            if np.linalg.norm(2*p1)>=30: break
        controls[i]=np.vstack([p1,rng.uniform(-15,15,(2,2)),-p1])
    p=np.einsum('tc,ncd->ntd',basis,controls)
    valid=np.diff(p[:,:,0],axis=1)!=0
    return p[:,:-1],valid

def max_signals(p,valid,z,m,ori):
    # Distances: N paths x 499 retained-candidate samples x K targets.
    dx=p[:,:,None,0]-z[None,None,:,0]
    dy=p[:,:,None,1]-z[None,None,:,1]
    r2=dx*dx+dy*dy+H*H
    dot=dx*ori[None,None,:,0]+dy*ori[None,None,:,1]
    scale=.1*m[None,None,:]/r2**1.5 # mu0/4pi times 1e6 -> microtesla
    bx=scale*(3*dx*dot/r2-ori[None,None,:,0])
    by=scale*(3*dy*dot/r2-ori[None,None,:,1])
    bz=scale*(3*H*dot/r2)
    total2=(EARTH[0]+bx)**2+(EARTH[1]+by)**2+(EARTH[2]+bz)**2
    signal=np.abs(np.sqrt(total2)-np.linalg.norm(EARTH))
    signal=np.where(valid[:,:,None],signal,0)
    d2=np.where(valid[:,:,None],dx*dx+dy*dy,np.inf)
    return signal.max(axis=1),d2.min(axis=1)<=4

def main():
    maxima=np.empty((SCENES,N,K),dtype=np.float32)
    circles=np.empty((SCENES,N,K),dtype=bool)
    moments=np.empty((SCENES,K)); params=np.empty((SCENES,K,6))
    for s in range(SCENES):
        z=rng.uniform(-10,10,(K,2))
        D=rng.uniform(.025,.030,K); L=rng.uniform(.8,1.2,K)
        f=rng.uniform(1,2,K)
        M=1.2706/(4*np.pi*1e-7)/f
        m=M*np.pi*D*D*L/4
        oi=rng.integers(0,4,K); ori=orientations[oi]
        p,valid=paths()
        maxima[s],circles[s]=max_signals(p,valid,z,m,ori)
        moments[s]=m; params[s]=np.column_stack([z,D,L,f,oi])
        if (s+1)%500==0: print(f'{s+1}/{SCENES} independent scenes',flush=True)
    peaks=np.maximum.accumulate(maxima,axis=1)
    geom=np.logical_or.accumulate(circles,axis=1)
    n=np.arange(N+1)
    summary={'seed':SEED,'scenes':SCENES,'field_model':'point dipole; exact scalar magnitude difference','noise_uT_per_axis':RNOISE,'earth_uT':EARTH.tolist(),'height_m':H,'moment_min_mean_max_Am2':[float(moments.min()),float(moments.mean()),float(moments.max())],'thresholds':{}}
    means={}; allmeans={}; allses={}
    for threshold in THRESHOLDS:
        hit=peaks>=threshold
        fraction=hit.mean(axis=2)
        allhit=np.stack([hit[:,:,:k].all(axis=2) for k in range(3,11)],axis=2)
        mean=np.r_[0,fraction.mean(axis=0)]
        am=np.vstack([np.zeros(8),allhit.mean(axis=0)])
        ase=np.vstack([np.zeros(8),allhit.std(axis=0,ddof=1)/np.sqrt(SCENES)])
        means[threshold]=mean; allmeans[threshold]=am; allses[threshold]=ase
        np.savetxt(OUT/f'threshold_{threshold:g}uT.csv',np.column_stack([n,mean,am,ase]),delimiter=',',header='n,expected_fraction_exposed,'+','.join(f'all_{k}' for k in range(3,11))+','+','.join(f'se_all_{k}' for k in range(3,11)),comments='')
        summary['thresholds'][str(threshold)]={str(i):{'fraction_pct':float(mean[i]*100),'all3_pct':float(am[i,0]*100),'all5_pct':float(am[i,2]*100),'all10_pct':float(am[i,7]*100),'expected_missed10':float(10*(1-mean[i])),'all10_mc95_halfwidth_pp':float(196*ase[i,7])} for i in [10,20,30,50]}
    np.savez_compressed(OUT/'scene_data.npz',max_signal_uT=maxima,circle_hit=circles,moments_Am2=moments,parameters=params,thresholds=THRESHOLDS)
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':220})
    fig,ax=plt.subplots(figsize=(9,5.7))
    ax.plot(n,means[3.]*100,color='#162f49',lw=2.5,label='Expected fraction of exposed targets')
    for k,c in [(3,'#278694'),(5,'#d9932d'),(10,'#925c9d')]:
        y=allmeans[3.][:,k-3]*100; se=allses[3.][:,k-3]*100
        ax.plot(n,y,color=c,lw=2,label=f'Probability all {k} targets are exposed')
        ax.fill_between(n,np.maximum(0,y-1.96*se),np.minimum(100,y+1.96*se),color=c,alpha=.13)
    ax.axvline(20,color='gray',ls=':',lw=1)
    ax.set(xlim=(0,50),ylim=(0,101),xlabel='Number of trajectories',ylabel='Percent (%)',title='Exposure to randomized reference-target fields\nDipole approximation | scalar anomaly threshold 3 µT')
    ax.grid(alpha=.17); ax.legend(loc='lower right',fontsize=9)
    fig.tight_layout(); fig.savefig(OUT/'physical_exposure.png'); fig.savefig(OUT/'physical_exposure.pdf'); plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(11.4,4.8),sharey=True)
    for th,c in zip(THRESHOLDS,['#278694','#162f49','#d9932d']):
        axs[0].plot(n,100*means[th],color=c,lw=2,label=f'{th:g} µT threshold')
        axs[1].plot(n,100*allmeans[th][:,7],color=c,lw=2,label=f'{th:g} µT threshold')
    axs[0].plot(n,np.r_[0,geom.mean(axis=(0,2))]*100,'--',color='#a35c8b',label='Fixed 2 m circle (same scenes)')
    axs[1].plot(n,np.r_[0,geom.all(axis=2).mean(axis=0)]*100,'--',color='#a35c8b',label='Fixed 2 m circle (same scenes)')
    for ax in axs:
        ax.axvline(20,color='gray',ls=':',lw=1)
        ax.set(xlim=(0,50),ylim=(0,101),xlabel='Number of trajectories'); ax.grid(alpha=.15); ax.legend(fontsize=8,loc='lower right')
    axs[0].set(ylabel='Percent (%)',title='Expected fraction exposed')
    axs[1].set_title('Probability all 10 targets are exposed')
    fig.tight_layout(); fig.savefig(OUT/'threshold_comparison.png'); plt.close(fig)
    assert all(np.all(np.diff(v)>=-1e-12) for v in means.values())
    assert np.all(means[2.]>=means[3.]) and np.all(means[3.]>=means[4.])
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
