EXP201027 - provisional field inputs, version 2: measured background

Two separately numbered input folders:
  disjoint_4/Bsim_tot_1.mat ... Bsim_tot_4.mat
  random_100/Bsim_tot_1.mat ... Bsim_tot_100.mat

Each MAT contains B_sim: a 300x300 double matrix in microtesla, NOT normalized.
Rows correspond to Y; columns to X; both axes run from 0 to 30 m.
Each map uses 20 device segments: five from each device A/B/C/D.
Disjoint set: 80 distinct device segments; no reuse anywhere in its four maps.
Random set: 100 distinct combinations; no within-map repeated segment, but
segments recur between maps and also overlap the disjoint set.
The two sets are NOT mutually disjoint.

Fusion follows MATLAB buildMatrix: at each observed cell uniformly choose
one valid sleeve value; do not average overlaps. Unobserved cells are filled
with 45.5767536335 microtesla, estimated from the new field measurements.
This is the median of device medians over reference seconds [310,340),
using time-uniform resampled values with equal weight per device.
It is a provisional background estimate, not an independently verified
target-free ambient measurement. See measured_background.json.
Only unobserved cells changed from v1; selections and observed cells match.
Each sleeve averages interpolated samples within a radius of 0.25 m.
Free-walk starts at reference time 310 s. Segments are 28 s long, with 500
uniformly timed interpolated support points. Coordinates are the frozen v1
reference, without further stretching, shifting, calibration or detrending.

manifest.csv records every map's segment IDs, fusion seed, area coverage,
range, and count of unique time windows. segments.csv maps IDs to raw files,
time intervals, and length estimates. report.json records settings.
reference/ preserves the coordinate transform, GPS-derived target estimates,
and synchronization conventions. These are approximate, not surveyed truth.

Rebuild both sets:
  pip install numpy scipy matplotlib
  python generate_sets.py
The bundled sleeves_trial.npz is the exact sleeve bank used; it also contains
sampled time, X, Y and total-field values. Raw recordings are not bundled.
The code regenerates selections, fusion, manifests and the preview.

INFERENCE:
Run your verified model and its verified preprocessing on B_sim.
Python loading example:
  from scipy.io import loadmat
  B = loadmat('disjoint_4/Bsim_tot_1.mat')['B_sim']
MATLAB loading example:
  s = load('disjoint_4/Bsim_tot_1.mat'); B = s.B_sim;

Do NOT invent B_theor files. No full ground truth map exists for this field
experiment. The public test_model.py requires theoretical labels; use an
input-only inference path in your own code. Do not fit normalization from
these files automatically unless that is your verified inference procedure.
Fitting min/max separately on the two sets can confound their comparison.

INTERPRETATION:
Phones were carried together; identical time windows on different devices
are repeated views of nearly the same walk. Four disjoint segment sets do
not constitute four independent experiments. Random-100 measures sensitivity
to segment selection AND random overlap fusion within this one experiment.
It does not provide 100 independent field trials. All settings remain
provisional pending successful validation of the inference pipeline.
