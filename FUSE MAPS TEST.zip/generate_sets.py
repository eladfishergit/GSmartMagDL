from pathlib import Path
import json,csv
import numpy as np
from scipy.io import savemat,loadmat
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
SEED=20261021
z=np.load(ROOT/'sleeves_trial.npz');A=z['sleeves_uT'];ids=z['segment_ids'];rng=np.random.default_rng(SEED)
groups=[np.flatnonzero(np.char.startswith(ids,p)) for p in 'ABCD']
shuffled=[rng.permutation(g) for g in groups]
sets={'disjoint_4':[np.sort(np.concatenate([g[k*5:(k+1)*5] for g in shuffled])) for k in range(4)]}
sets['random_100']=[];seen=set()
while len(sets['random_100'])<100:
 s=np.sort(np.concatenate([rng.choice(g,5,replace=False) for g in groups]));key=tuple(s)
 if key not in seen:seen.add(key);sets['random_100'].append(s)
assert len(set(np.concatenate(sets['disjoint_4'])))==80
q=float(json.loads((ROOT/'measured_background.json').read_text())['background_uT']);rows=[];previews=[]
def cells(mask):
 ix=np.argwhere(mask)+1;c=np.empty((1,len(ix)),dtype=object)
 for j,v in enumerate(ix):c[0,j]=v[None,:]
 return c
for name,selections in sets.items():
 out=ROOT/name;out.mkdir(exist_ok=True)
 for k,s in enumerate(selections,1):
  assert len(s)==len(set(s))==20
  assert all(sum(ids[i].startswith(p) for i in s)==5 for p in 'ABCD')
  fusion_seed=SEED+(0 if name=='disjoint_4' else 10000)+k
  r=np.random.default_rng(fusion_seed);chosen=A[s];valid=np.isfinite(chosen);cover=valid.any(0)
  score=r.random(chosen.shape);score[~valid]=-1;winner=score.argmax(0)
  B=np.take_along_axis(chosen,winner[None],axis=0)[0];B[~cover]=q
  assert np.isfinite(B).all() and B.shape==(300,300)
  assert np.all(np.any(np.isclose(chosen[:,cover],B[cover]),axis=0))
  fn=out/f'Bsim_tot_{k}.mat'
  savemat(fn,dict(B_sim=B,NMtraj=cells(cover),NMreka=cells(~cover),coverage_mask=cover,selected_segment_ids=ids[s].astype(object),fusion_seed=fusion_seed,x_m=np.linspace(0,30,300),y_m=np.linspace(0,30,300),background_uT=q),do_compression=False)
  assert np.array_equal(loadmat(fn)['B_sim'],B)
  rows.append(dict(set=name,map_index=k,file=str(fn.relative_to(ROOT)),fusion_seed=fusion_seed,coverage_percent=100*cover.mean(),min_uT=B.min(),max_uT=B.max(),unique_time_windows=len(set(int(v[1:]) for v in ids[s])),segment_ids=';'.join(ids[s])))
  if name=='disjoint_4':previews.append(B)
with (ROOT/'manifest.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
report={'seed':SEED,'available_segments':len(ids),'unused_in_disjoint':sorted(set(ids)-set(ids[np.concatenate(sets['disjoint_4'])])),'counts':{k:len(v) for k,v in sets.items()},'normalization':'none; B_sim in microtesla','background_uT':q,'sleeve_radius_m':.25,'window_start_s':310,'window_duration_s':28,'support_samples_per_segment':500,'source_commit':'f5d07a58165761c5b278c1bad98d5bd7ab2edc44','coverage':{k:[min(r['coverage_percent'] for r in rows if r['set']==k),max(r['coverage_percent'] for r in rows if r['set']==k)] for k in sets}}
(ROOT/'report.json').write_text(json.dumps(report,indent=2))
fig,axs=plt.subplots(1,4,figsize=(16,4));lo=min(b.min() for b in previews);hi=max(b.max() for b in previews)
ref=json.loads((ROOT/'reference/reference.json').read_text())
for k,(ax,B) in enumerate(zip(axs,previews),1):
 im=ax.imshow(B,origin='lower',extent=[0,30,0,30],cmap='turbo',vmin=lo,vmax=hi);ax.set_title(f'Map {k} | {rows[k-1]["coverage_percent"]:.1f}% area');ax.set_xlabel('X (m)')
 for t in ref['targets']:
  x,y=t['xy_m'];ax.plot(x,y,'kx',ms=5)
axs[0].set_ylabel('Y (m)');fig.colorbar(im,ax=axs,shrink=.7,label='microtesla');fig.savefig(ROOT/'disjoint_preview.png',dpi=150,bbox_inches='tight')
print(json.dumps(report,indent=2));print('PASS: no repeated segments in disjoint set, no within-map repeats, equal phone counts, finite maps, fusion membership, all MAT round trips')
