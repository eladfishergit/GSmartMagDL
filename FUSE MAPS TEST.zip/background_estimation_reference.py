from pathlib import Path
import numpy as np,json
p=Path(__file__).resolve().parent
z=np.load(p/'sleeves_trial.npz'); samples=z['support_samples']; ids=z['segment_ids']; med={}
for phone in 'ABCD':
 a=np.concatenate([samples[i] for i,v in enumerate(ids) if v.startswith(phone)])
 a=a[(a[:,0]>=310)&(a[:,0]<340)]; _,ix=np.unique(a[:,0],return_index=True)
 med[phone]=float(np.median(a[ix,3]))
print(json.dumps({'device_medians_uT':med,'background_uT':float(np.median(list(med.values())))},indent=2))
