# EXP201027 frozen working reference v1

Use reference.json as the authoritative source for future processing. Do not rerun a fit to the sketch or infer the origin from a recording start. coordinates.py converts original GPS to the accepted frame and back. All processing hereafter must identify this reference version.

## Exact convention (also usable in MATLAB)

E = (longitude - anchor_longitude) * metres_per_degree.east

N = (latitude - anchor_latitude) * metres_per_degree.north

[X,Y] = [E,N] * R + translation_xy_m

R is the row-vector matrix in reference.json. A column-vector implementation must transpose R. The inverse is [E,N] = ([X,Y]-translation_xy_m)*R'. Geographic coordinates are degrees; local coordinates are metres. This is the original local linear geographic approximation, not a new UTM/ENU conversion. Preserve its constants for reproducibility.

## Scope

- One shared translation and proper rotation applies to all phones and all recording phases. No per-phone spatial correction, scaling, reflection or normalization.
- All four target centers use robust circle fits to distinct GPS update positions from multi. No target separation of 2 m was imposed. Target pair separation is about 2.312 m. C1 is the later loop (234-243 s), C2 the earlier (219-233 s). These are working identities and estimated centers, not surveyed positions.
- Origin and orientation minimize squared deviations of the four centers from the approximate sketch, using rigid Procrustes fitting. Consequently the origin is conventional and the sketch residual is not a GPS accuracy estimate.
- The time reference is UTC 2026-10-20 14:01:56.000. multi starts at reference time 0.381 s: do not subtract its first sample when applying the frozen target windows. For other recordings add the offsets in reference.json to the original numeric CSV time. GPS-derived offsets can include GPS latency and are preliminary sensor synchronization, not validated magnetic-channel synchronization.
- Freestyle start at reference time 310 s is provisional. Gaps and cold-start invalid GPS must be handled explicitly later; no smoothing/filtering pipeline has been approved.
- Nominal network coordinates [0,30] by [0,30] m are parallel to the accepted axes. Data extend outside this window. Crop/padding, final extent, grid indexing and image row direction have NOT been fixed; do not silently clip or stretch. If a later grid needs an origin offset, record it as a separate transform.
- No magnetic processing, fusion, segmentation or network preprocessing is fixed by this bundle.

The JSON records source SHA256 hashes and full-precision constants. targets.csv is a convenient export. reference_map.png is a visual check. Raw files remain in the source Drive folder EXP201027; this bundle does not duplicate them.

Run `python coordinates.py` to validate origin, target coordinates, inverse conversion and the rotation matrix.
