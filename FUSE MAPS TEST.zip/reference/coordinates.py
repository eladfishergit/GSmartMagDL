"""Frozen working transform. Requires numpy. Never refits the reference frame."""
import json
from pathlib import Path
import numpy as np

CONFIG = json.loads(Path(__file__).with_name('reference.json').read_text())
R = np.array(CONFIG['row_vector_rotation_EN_to_XY'])
B = np.array(CONFIG['translation_xy_m'])
A = CONFIG['gps_anchor']
K = CONFIG['metres_per_degree']

def gps_to_xy(latitude, longitude):
    """Scalar or broadcastable arrays -> (..., 2) X,Y in metres."""
    lat, lon = np.broadcast_arrays(latitude, longitude)
    en = np.stack([(lon-A['longitude'])*K['east'],
                   (lat-A['latitude'])*K['north']], axis=-1)
    return en @ R + B

def xy_to_gps(x, y):
    """Return (..., 2) latitude,longitude in degrees."""
    x, y = np.broadcast_arrays(x, y)
    en = (np.stack([x,y],axis=-1)-B) @ R.T
    return np.stack([A['latitude']+en[...,1]/K['north'],
                     A['longitude']+en[...,0]/K['east']],axis=-1)

if __name__ == '__main__':
    for target in CONFIG['targets']:
        xy = gps_to_xy(target['latitude'], target['longitude'])
        assert np.allclose(xy, target['xy_m'], atol=1e-7)
        assert np.allclose(xy_to_gps(*xy), [target['latitude'],target['longitude']],atol=1e-10,rtol=0)
        print(target['id'], xy)
    assert np.allclose(gps_to_xy(**CONFIG['origin_gps']), [0,0], atol=1e-7)
    assert np.allclose(R.T @ R, np.eye(2), atol=1e-12)
    assert np.isclose(np.linalg.det(R), 1)
    print('PASS: targets, origin, round trips, distance-preserving rotation.')
