from pathlib import Path
import json,csv
import numpy as np
from scipy.io import savemat,loadmat
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
BANK=ROOT.parent/'EXP201027_fusemap_sets_v2'
z=np.load(BANK/'sleeves_trial.npz');ids=z['segment_ids'];s=z['support_samples'];A=z['sleeves_uT'];ref=json.load(open(BANK/'reference/reference.json'));T=np.array([t['xy_m'] for t in ref['targets']])
p=s[:,:-1,1:3];v=np.diff(s[:,:,1:3],axis=1);w=T[None,None,:,:]-p[:,:,None,:];u=np.clip((w*v[:,:,None,:]).sum(-1)/(v*v).sum(-1)[:,:,None].clip(1e-20),0,1);d=np.linalg.norm(w-u[:,:,:,None]*v[:,:,None,:],axis=-1).min(1)
radius=.75;seed=20261022;rng=np.random.default_rng(seed);eligible=d.min(1)>=radius
chosen=np.sort(np.concatenate([rng.choice(np.flatnonzero(eligible&np.char.startswith(ids,c)),5,replace=False) for c in 'ABCD']))
values=A[chosen];valid=np.isfinite(values);mask=valid.any(0);scores=rng.random(values.shape);scores[~valid]=-1;win=scores.argmax(0);B=np.take_along_axis(values,win[None],axis=0)[0];q=45.57675363349968;B[~mask]=q
assert len(set(chosen))==20 and np.all(d[chosen]>=radius)
def cells(mask):
 ix=np.argwhere(mask)+1;c=np.empty((1,len(ix)),dtype=object)
 for j,v in enumerate(ix):c[0,j]=v[None,:]
 return c
savemat(ROOT/'Bsim_tot_1.mat',dict(B_sim=B,coverage_mask=mask,NMtraj=cells(mask),NMreka=cells(~mask),background_uT=q,selected_segment_ids=ids[chosen].astype(object),minimum_distance_per_target_m=d[chosen].min(0),selection_seed=seed,exclusion_radius_m=radius),do_compression=False)
check=loadmat(ROOT/'Bsim_tot_1.mat');assert np.array_equal(check['B_sim'],B) and 'NMreka' in check
report={'selection':'Random 5 per phone from segments at least 0.75m from ALL target reference centers; conditioned on target coordinates, not an unbiased random sample','seed':seed,'selected_ids':ids[chosen].tolist(),'minimum_distance_per_target_m':d[chosen].min(0).tolist(),'coverage_percent':100*mask.mean(),'eligible_segments':int(eligible.sum()),'background_uT':q,'notes':['Distances are point-to-polyline distances in frozen GPS reference frame, not surveyed physical clearances.','Sleeve radius 0.25m.','Phone paths share physical walking; no independent-trial claim.','No inference performed.']}
(ROOT/'selection.json').write_text(json.dumps(report,indent=2))
with (ROOT/'distances.csv').open('w',newline='') as f:
 wr=csv.writer(f);wr.writerow(['segment_id','selected','C1_m','C2_m','C3_m','C4_m'])
 for i in range(len(ids)):wr.writerow([ids[i],i in chosen,*d[i]])
fig,axs=plt.subplots(1,2,figsize=(12,5.5),layout='constrained');colors=dict(zip('ABCD',['#0072B2','#E69F00','#009E73','#CC79A7']))
for c in 'ABCD':
 for j,i in enumerate([i for i in chosen if ids[i].startswith(c)]):axs[0].plot(s[i,:,1],s[i,:,2],c=colors[c],lw=1,label=c if j==0 else None)
axs[0].legend(title='Phone');axs[0].set_title('Selected GPS paths | exclusion radius 0.75 m')
im=axs[1].imshow(B,origin='lower',extent=[0,30,0,30],cmap='turbo');fig.colorbar(im,ax=axs[1],label='microtesla');axs[1].set_title('FUSEMAP | 20 segments, 5 per phone')
for ax in axs:
 for t in ref['targets']:
  x,y=t['xy_m'];ax.plot(x,y,'kx',ms=7);ax.annotate(t['id'],(x,y),xytext=(4,4),textcoords='offset points');ax.add_patch(plt.Circle((x,y),radius,fill=False,color='black',ls='--',lw=.8))
 ax.set(xlim=(0,30),ylim=(0,30),xlabel='Reference X (m)',ylabel='Reference Y (m)',aspect='equal')
fig.savefig(ROOT/'near_targets_fusemap.png',dpi=160)
(ROOT/'README.txt').write_text('Exploratory target-conditioned selection, not independent validation or an unbiased random sample. 20 distinct device segments, five per phone. All sampled GPS polylines stay >=0.75m from each frozen target reference center. Target positions and GPS are approximate. No guarantee of physical clearance or anomaly detection. Observed values unchanged; measured background 45.57675363349968 uT. No normalization. Reproduce by placing this folder beside EXP201027_fusemap_sets_v2 and running create_map.py (numpy scipy matplotlib).\n')
print(json.dumps(report,indent=2))
